console.log('Hello World!');
<input type="button" value="버튼" onClick="window.open('https://youtube.com/channel/UCdzKdBUIDVTny9uspDWBuvg')">